<?php
namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\AppSetup;
use app\models\Product;
use app\models\Variant;
use app\components\Shopify;
use yii\helpers\Url;
use yii\helpers\Html;

class SiteController extends Controller
{
     public function beforeAction($action) { 
      $this->enableCsrfValidation = false; 
      return parent::beforeAction($action); 
    }
    
/**
* Displays homepage.
*
* @return string
*/
public function actionIndex()
{
  return $this->render('index');
}

/**
* Login action.
*
* @return Response|string
*/
public function actionLogin()
{
  if (!Yii::$app->user->isGuest) {
    return $this->goHome();
  }

  $model = new LoginForm();
  if ($model->load(Yii::$app->request->post()) && $model->login()) {
    return $this->goBack();
  }

  $model->password = '';
  return $this->render('login', [
    'model' => $model,
  ]);
}

/**
* Logout action.
*
* @return Response
*/

public function actionLogout()
{
  Yii::$app->user->logout();
  return $this->goHome();
}

public function actionQuenswaystock(){
  // echo '<pre>';
  // print_r($_REQUEST['inventory_item_id']); exit;
  if(!empty($_REQUEST)):
  $app_setup = new AppSetup();
  $loc_id = 49848851;
  $inventory_item_id = $_REQUEST['inventory_item_id'];
  $variant_exist = Variant::find()->Where(['inventory_item_id' => $inventory_item_id])->one();
  $queen_stock =  self::get_stock($loc_id, $inventory_item_id);
  $variant_exist->queeninventory = $queen_stock;
  $variant_exist->stock_queens_status = 1;
  $variant_exist->save(false);
  return true;
endif;
}

public function actionRonswaystock($inventory_item_id){
  if(!empty($_REQUEST)):
  $app_setup = new AppSetup();
  $loc_id = 14372274199;
  $inventory_item_id = $_REQUEST['inventory_item_id'];
  $variant_exist = Variant::find()->Where(['inventory_item_id' => $inventory_item_id])->one();
  $queen_stock =  self::get_stock($loc_id, $inventory_item_id);
  $variant_exist->queeninventory = $queen_stock;
  $variant_exist->stock_rons_status = 1;
  $variant_exist->save(false);
  return true;
  endif;
}

public function actionWilsonstock($inventory_item_id){
  if(!empty($_REQUEST)):
  $app_setup = new AppSetup();
  $loc_id = 14372306967;
  $inventory_item_id = $_REQUEST['inventory_item_id'];
  $variant_exist = Variant::find()->Where(['inventory_item_id' => $inventory_item_id])->andWhere(['stock_wils_status'=> 0])->one();
  $queen_stock =  self::get_stock($loc_id, $inventory_item_id);
  $variant_exist->queeninventory = $queen_stock;
  $variant_exist->stock_wils_status = 1;
  $variant_exist->save(false);
  return true;
  endif;
}

// public function actionSetstatus(){
//     Yii::$app->db->createCommand()->update('variant', ['stock_wils_status' => 0,'stock_rons_status' => 0,'stock_queens_status' => 0])->execute();
//     $fh = fopen(dirname(__FILE__) . '/' . 'pageno.txt', 'a');
//     fclose($fh);
//     unlink(dirname(__FILE__) . '/' . 'pageno.txt');
// }

public function actionProductlist()
{    
  $app_setup = new AppSetup();
  $session = Yii::$app->session;
  $session->open();
  $shop_name = $session->get('shop');
  $app_install = AppSetup::find()->Where(['id' => 1])->one();
  $shop = $app_install['shop'];
  $token = $app_install['token'];
  $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);
  $limit = 25;
  $scroll_id = '';
  $product_type=isset($_GET['product_type'])? $_GET['product_type']:'';
  $vendor=isset($_GET['vendor'])? $_GET['vendor']:'';
  $location = isset($_GET['location'])? $_GET['location']:'Queensway';
  $query=isset($_GET['query'])? $_GET['query']:'';
  $pn=isset($_GET['page'])? $_GET['page']:1;
  $where =array();
   if(!empty($product_type)){
      $where['product_type']=$product_type;
   }
   if(!empty($vendor)){
      $where['vendor']=$vendor;
   }
  $offset = ($pn-1) * $limit;
  if(empty($query)){
    $total_records = count (Product::find()->Where($where)->all());
    $products_details = Product::find()->Where($where)->orderBy(['title'=> SORT_ASC])->limit($limit)->offset($offset)->all();
  }
  else
  {
    $total_records = count (Product::find()->Where($where)->andWhere(['like','title',$query])->all());
    $products_details = Product::find()->Where($where)->andWhere(['like','title',$query])->orderBy(['title'=> SORT_ASC])->limit($limit)->offset($offset)->all();
  }
  $variant_details = array();
  $model = new Variant();

  foreach ($products_details as $value) { 
    $variant_details[] = Variant::find()->Where(['product_id' => $value['product_id']])->all();
  }
    $loctaion_list = $sc->call('GET', '/admin/api/2019-04/locations.json');
  $vender_list = Product::find()->select(['vendor'])->distinct()->all();
  $product_type_list = Product::find()->select(['product_type'])->distinct()->all();
  return $this->render('productlist',array('productlist' => $products_details,'variant_details' => $variant_details,'vender_list'=>$vender_list,'product_type_list'=>$product_type_list,'model' => $model,'count'=>$total_records,'page_no'=>$pn,'sel_product'=>$product_type,'sel_vendor'=>$vendor,'query'=>$query,'loctaion_list'=>$loctaion_list,'sel_location'=>$location,'scroll_id'=>$scroll_id));
}

public function actionEdit()
{  
  $app_setup = new AppSetup();
  $session = Yii::$app->session;
  $session->open();
  $shop_name = $session->get('shop');
  $app_install = AppSetup::find()->Where(['id' => 1])->one();
  $shop = $app_install['shop'];
  $token = $app_install['token'];
  $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);

  if(isset($_POST['Variant']['variants_id'])) {
    $id = $_POST['Variant']['variants_id'];
  } else {
    $id = '';
  }
 if(isset($_POST['Variant']['variants_id'])){
    $id = $_POST['Variant']['variants_id'];
    $model = Variant::find()->Where(['variants_id' => $id])->one();
    if ($model->load(Yii::$app->request->post()))
    {
      $queenLevel = Yii::$app->request->post()['Variant']['queenLevel'];
      $ronLevel = Yii::$app->request->post()['Variant']['ronLevel'];
      $wilsonLevel = Yii::$app->request->post()['Variant']['wilsonLevel'];
      Yii::$app->db->createCommand()->update('variant', ['queenLevel' => $queenLevel,'ronLevel' => $ronLevel,'wilsonLevel' => $wilsonLevel], 'variants_id='.$id)->execute();    
    //Yii::$app->session->setFlash('packageFormSubmitted');
    }  
    else
    {
      $errors = $model->getErrors();
      if (isset($errors) && count($errors) > 0)
      {
        foreach($errors as $key => $val)
        {
          Yii::$app->session->setFlash('error', $val[0]);
        }
      }
    }
  } 
  else
  {
  Yii::$app->session->setFlash('ErrorWithoutid');
  }

  $variant_details = array();   
  $limit = 25;

  $product_type=isset($_GET['product_type'])? $_GET['product_type']:'';
  $vendor=isset($_GET['vendor'])? $_GET['vendor']:'';
  $query=isset($_GET['query'])? $_GET['query']:'';
  $pn=isset($_GET['page'])? $_GET['page']:1;
  $location = isset($_GET['location'])? $_GET['location']:'';
  $where =array();
  if(!empty($product_type)){
   $where['product_type']=$product_type;
  }
  if(!empty($vendor)){
   $where['vendor']=$vendor;
  }
  $offset = ($pn-1) * $limit;
  if(empty($query)){
   $total_records = count (Product::find()->Where($where)->all());
   $products_details = Product::find()->Where($where)->limit($limit)->offset($offset)->all();
  }
  else {
   $total_records = count (Product::find()->Where($where)->andWhere(['like','title',$query])->all());
   $products_details = Product::find()->Where($where)->andWhere(['like','title',$query])->limit($limit)->offset($offset)->all();
  }
  foreach ($products_details as $value) { 
   $variant_details[] = Variant::find()->Where(['product_id' => $value['product_id']])->all();
  }
  $vender_list = Product::find()->select(['vendor'])->distinct()->all();
  $product_type_list = Product::find()->select(['product_type'])->distinct()->all();  
  $loctaion_list = $sc->call('GET', '/admin/api/2019-04/locations.json');
  return $this->render('productlist',array('productlist' => $products_details,'variant_details' => $variant_details,'vender_list'=>$vender_list,'product_type_list'=>$product_type_list,'model' => $model,'count'=>$total_records,'page_no'=>$pn,'sel_product'=>$product_type,'sel_vendor'=>$vendor,'query'=>$query,'loctaion_list'=>$loctaion_list,'sel_location'=>$location,'scroll_id'=>$id));
}


public function actionExport()
{  
  $app_setup = new AppSetup();
  $product_type=isset($_GET['product_type'])? $_GET['product_type']:'';
  $vendor=isset($_GET['vendor'])? $_GET['vendor']:'';
  $query=isset($_GET['query'])? $_GET['query']:'';
   
  $where =array();
  if(!empty($product_type)){
   $where['product_type']=$product_type;
  }
  if(!empty($vendor)){
    $where['vendor']=$vendor;
  }
  if(empty($query)){
   $products_details = Product::find()->Where($where)->all();
  }
  else{
   $products_details = Product::find()->Where($where)->andWhere(['like','title',$query])->all();
  }
  $variant_details = array();
  foreach ($products_details as $value){
    $variant_details[] = Variant::find()->Where(['product_id' => $value['product_id']])->all();
  }
  $delimiter = ",";
  $filename = "levelapp_" . date('Y-m-d') . ".csv";

  //create a file pointer
  $f = fopen('php://memory', 'w');
  $i = 0;
  $fields = array('Product ID', 'Title', 'Vendor', 'Product Type', 'Queensway Level','Queensway Inventory','Queensway To Be Order', 'Roncesvalles Levle','Roncesvalles Inventory','Roncesvalles To Be Order', 'Wilson Levle','Wilson Inventory','Wilson To Be Order');
  fputcsv($f, $fields, $delimiter);
  $lineData = array();
  foreach ($products_details as $value) {
  $lineData = array($i, $value['title'], $value['vendor'], $value['product_type'], "","","","","","","","","");
  fputcsv($f, $lineData, $delimiter);
  foreach ($variant_details as $var) { 
  $m =0;
  foreach ($var as $variant_pr) {
    $queenorder = $variant_pr['queenLevel'] - $variant_pr['queeninventory'];
    $ronorder = $variant_pr['ronLevel'] - $variant_pr['roninventory'];
    $wilsonorder = $variant_pr['wilsonLevel'] - $variant_pr['wilsoninventory'];
  if($variant_pr['product_id'] == $value['product_id']){
  $lineData = array($variant_pr['variants_id'], $variant_pr['title'], $value['vendor'], $value['product_type'], $variant_pr['queenLevel'],$variant_pr['queeninventory'],$queenorder,$variant_pr['ronLevel'],$variant_pr['roninventory'],$ronorder,$variant_pr['wilsonLevel'],$variant_pr['wilsoninventory'],$wilsonorder);
  fputcsv($f, $lineData, $delimiter);

  }
  $m++;
  }
  }
  $i++;
  }
 fseek($f, 0);
 header('Content-Type: text/csv');
  header('Content-Disposition: attachment; filename="' . $filename . '";');
  fpassthru($f);
  exit;
}

/* Webhooks for app */
public static function ShopifyHooks($shopifyClient, $shopify_shop) 
{
    $logs = fopen("hooks.txt", "a") or die("Unable to open file!");
    $base_url = Yii::$app->params['BASE_URL'];
    $hooks = array();
    try {
            $hooks_tag = $shopifyClient->call('GET', '/admin/webhooks.json');
            fwrite($logs, "\n Hook list:" . json_encode($hooks_tag));
            foreach ($hooks_tag as $exist_hooks) {
                $hooks[] = $exist_hooks['topic'];
        }
        fwrite($logs, "\n [" . date("Y-m-d H:i:s A") . "] Hooks :" . json_encode($hooks));
        if (!in_array("app/uninstalled", $hooks)) {
            $uninstall_hook = array(
                    "webhook" => array(
                        "topic" => "app/uninstalled",
                        "address" => $base_url . "/site/uninstall?shop=" . $shopify_shop . "",
                        "format" => "json"
                    )
                );
                $hooks_tag = $shopifyClient->call('POST', '/admin/webhooks.json', $uninstall_hook);
        }
        if (!in_array("products/delete", $hooks)) {
                $product_delete_hook = array(
                    "webhook" => array(
                        "topic" => "products/delete",
                        "address" => $base_url . "/site/delete?shop=" . $shopify_shop . "",
                        "format" => "json"
                    )
                );
                $delete_tag = $shopifyClient->call('POST', '/admin/webhooks.json', $product_delete_hook);
        }
       if (!in_array("products/create", $hooks)) {
                $product_create_hook = array(
                    "webhook" => array(
                        "topic" => "products/create",
                        "address" => $base_url . "/site/create?shop=" . $shopify_shop . "",
                        "format" => "json"
                    )
                );
             $create_tag = $shopifyClient->call('POST', '/admin/webhooks.json', $product_create_hook);
          }   
      if (!in_array("products/update", $hooks)) {
                $product_create_hook = array(
                    "webhook" => array(
                        "topic" => "products/update",
                        "address" => $base_url . "/site/update?shop=" . $shopify_shop . "",
                        "format" => "json"
                    )
                );
             $create_tag = $shopifyClient->call('POST', '/admin/webhooks.json', $product_create_hook);
       } 

        if (!in_array("inventory_items/update", $hooks)) {
                $product_create_hook = array(
                    "webhook" => array(
                        "topic" => "inventory/update",
                        "address" => $base_url . "/site/inventory?shop=" . $shopify_shop . "",
                        "format" => "json"
                    )
                );
             $create_tag = $shopifyClient->call('POST', '/admin/webhooks.json', $product_create_hook);
       } 

      } 
  catch (Exception $exc)
  {
      echo "<pre>";
      print_r($exc);
      die('hook');
  }
}



public function actionCreate() {
  /// Send 200 ok status /
  ignore_user_abort(true);
  ob_start();
  $serverProtocole = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
  header($serverProtocole . ' 200 OK');
  header('Content-Encoding: none');
  header('Content-Length: ' . ob_get_length());
  header('Connection: close');
  ob_end_flush();
  ob_flush();
  flush();
  /// End send ok status /
  $webhookContent = '';
  $webhook = fopen('php://input', 'rb');
  while (!feof($webhook))
    {
       $webhookContent .= fread($webhook, 4096);
    }
    $log =fopen('createproduct.txt','a');
    $txt="";
    $result_web = json_decode($webhookContent);
    fwrite($log ,"\n  new created - ".json_encode($result_web)); 

    $product_exist = Product::find()->Where(['product_id' => $result_web->id])->one();
    if(empty($product_exist)){
      fwrite($log, 'added for product');
      fwrite($log,"\n 'hhi' $result_web->id,$result_web->title,$result_web->vendor,$result_web->product_type,$result_web->image->src");  
        $product = new Product();
        $product->product_id = $result_web->id;
        $product->title = $result_web->title;
        $product->vendor = $result_web->vendor;
        $product->image_src = $result_web->image->src;
        $product->product_type = $result_web->product_type;
        $product->save(false);
       // fwrite($log,"\n $result_web->id,$result_web->title,$result_web->vendor,$result_web->product_type,$result_web->image->src");  
    //  if ($product->save(false)){
        //fwrite($log, 'Product saveds');
        $variant = $result_web->variants;
        fwrite($log, "\n varient saveds". json_encode($variant));
        foreach ($variant as $value) {
          fwrite($log, 'variant start');
            $variant = new Variant();
            $variant->product_id = $value->product_id;
            $variant->title = $value->title;
            $variant->price = $value->price;
            $variant->inventory_item_id = $value->inventory_item_id;
            $variant->inventory_quantity = $value->inventory_quantity;
            $variant->old_inventory_quantity = $value->old_inventory_quantity;
            $variant->variants_id = $value->id;
            fwrite($log, 'variant saved');
            // find out the Sc
            $app_setup = new AppSetup();
            $session = Yii::$app->session;
            $session->open();
            $shop_name = Yii::$app->request->get('shop');
            $app_install = AppSetup::find()->Where(['shop' =>'vapeluv.myshopify.com'])->one();
            $shop = $app_install['shop'];
            $token = $app_install['token'];
            $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);
            $inventory_details = $sc->call('GET', '/admin/api/2019-04/inventory_levels.json?inventory_item_ids='.$value->inventory_item_id);
            foreach ($inventory_details as $loc)
            {
                if($loc['location_id'] == '49848851' ){        
                 $variant->stock_queens_status = 1;
                 $variant->queeninventory = $loc['available'];        
                }
                if($loc['location_id'] == '14372274199'){
                 $variant->stock_rons_status = 1;
                 $variant->roninventory = $loc['available'];
                }

                if($loc['location_id'] == '14372306967')
                {   
                 $variant->stock_wils_status = 1;
                 $variant->wilsoninventory = $loc['available']; 
                }
            }
         $variant->save(false);
        }
   // }
  }
    
}

public function actionUpdate(){
  /// Send 200 ok status /
  ignore_user_abort(true);
  ob_start();
  $serverProtocole = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
  header($serverProtocole . ' 200 OK');
  header('Content-Encoding: none');
  header('Content-Length: ' . ob_get_length());
  header('Connection: close');
  ob_end_flush();
  ob_flush();
  flush();
  /// End send ok status /
  $webhookContent = '';
  $webhook = fopen('php://input', 'rb');
  while (!feof($webhook))
    {
       $webhookContent .= fread($webhook, 4096);
    }
    $log =fopen('updateProduct.txt','a');
    $txt="";
    $result_web = json_decode($webhookContent);
    fwrite($log,"\n initial array -".json_encode($result_web));
    fwrite($log,"\n updated Product id -".$result_web->id);
    $product_exist = Product::find()->Where(['product_id' => $result_web->id])->one();
    $product_exist->product_id = $result_web->id;
    $product_exist->title = $result_web->title;
    $product_exist->vendor = $result_web->vendor; 
    $product_exist->product_type = $result_web->product_type;
    $product_exist->save(false);
    $variant = $result_web->variants;
   // fwrite($log,"\n variant array -".json_encode($variant));
    foreach ($variant as $value) {
        //fwrite($log,"\n id -".$value->id.'product-id -'.$result_web->id);
     // fwrite($log,"$value->id, $value->product_id,$value->title ,$value->price,$value->inventory_item_id,$value->inventory_quantity,$value->old_inventory_quantity");
        $variant_exist = Variant::find()->Where(['variants_id' => $value->id])->one();
        $variant_exist->product_id = $value->product_id;
        $variant_exist->title = $value->title;
        $variant_exist->price = $value->price;
        $variant_exist->inventory_item_id = $value->inventory_item_id;
        $variant_exist->inventory_quantity = $value->inventory_quantity;
        $variant_exist->old_inventory_quantity = $value->old_inventory_quantity;
        $variant_exist->variants_id = $value->id;
        // find out the Sc
        $app_setup = new AppSetup();
        $session = Yii::$app->session;
        $session->open();
        $shop_name = Yii::$app->request->get('shop');
        $app_install = AppSetup::find()->Where(['shop' =>'vapeluv.myshopify.com'])->one();
        $shop = $app_install['shop'];
        $token = $app_install['token'];
        // fwrite($log, $shop);
        // fwrite($log, $token);
        $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);
        $inventory_details = $sc->call('GET', '/admin/api/2019-04/inventory_levels.json?inventory_item_ids='.$value->inventory_item_id);
        //   fwrite($log, "\n 852");
        // fwrite($log,"\n variant array -".json_encode($inventory_details)); 

        foreach ($inventory_details as $loc){
            if($loc['location_id'] == '49848851' ){     
              fwrite($log, "\n location".$loc['location_id']);
              fwrite($log, "\n avialable".$loc['available']);   
              $variant_exist->stock_queens_status = 1;
              $variant_exist->queeninventory = $loc['available'];      
            }
            if($loc['location_id'] == '14372274199'){
              fwrite($log, "\n location".$loc['location_id']);
              fwrite($log, "\n avialable".$loc['available']); 
              $variant_exist->stock_rons_status = 1;
              $variant_exist->roninventory = $loc['available']; 
            }

            if($loc['location_id'] == '14372306967')
            {   
              fwrite($log, "\n location".$loc['location_id']);
              fwrite($log, "\n avialable".$loc['available']); 
              $variant_exist->stock_wils_status = 1;
              $variant_exist->wilsoninventory = $loc['available'];
            }
       }
        $variant_exist->save(false);     
    }

//fwrite($log, json_encode($txt));   
}

public function actionCheckstatus() {
   Yii::$app->response->statusCode = 200;
  print_r(Yii::$app->response->statusCode);
}



public function actionDelete() {
 /// Send 200 ok status /
ignore_user_abort(true);
ob_start();
$serverProtocole = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
header($serverProtocole . ' 200 OK');
header('Content-Encoding: none');
header('Content-Length: ' . ob_get_length());
header('Connection: close');
ob_end_flush();
ob_flush();
flush();
/// End send ok status /
/// End send ok status /
$filename = "deleteProduct";
$log =fopen($filename,'a');
fwrite($log, date("M,d,Y h:i:s A") . "\n");


}



public function actionInventory() {
 /// Send 200 ok status /
  Yii::$app->response->statusCode = 200;
  // ignore_user_abort(true);
  // ob_start();
  // $serverProtocole = filter_input(INPUT_SERVER, 'SERVER_PROTOCOL', FILTER_SANITIZE_STRING);
  // header($serverProtocole . ' 200 OK');
  // header('Content-Encoding: none');
  // header('Content-Length: ' . ob_get_length());
  // header('Connection: close');
  // ob_end_flush();
  // ob_flush();
  // flush();
  // / End send ok status /
  // $webhookContent = '';
  // $webhook = fopen('php://input', 'rb');
  // while (!feof($webhook)) {
  // $webhookContent .= fread($webhook, 4096);
  // }
  // $result_web = json_decode($webhookContent);

  // $log =fopen('updateInventoryProduct.txt','a');
  // fwrite($log, json_encode($result_web));
}




public function actionInstall()
{   
  $shopify_shop = isset($_GET['shop']) ? $_GET['shop'] : '';
  $code = isset($_GET['code']) ? $_GET['code'] : '';
  $app_key = Yii::$app->params['APP_KEY'];
  $app_secret = Yii::$app->params['SECRET_KEY'];
  $base_url = Yii::$app->params['BASE_URL'];
  $app_installed = AppSetup::find()->Where(['shop' => $shopify_shop])->one();
  if (!empty($app_installed)){ 
     $shopify_shop = $app_installed->shop;
     $shopify_token = $app_installed->token; 
  } 
  else
  {
    $shopifyClient = new Shopify($shopify_shop, "", $app_key, $app_secret);
    $shopify_token = $shopifyClient->getAccessToken($code);

    if (empty($shopify_token)) {
      $shopify_scope = Yii::$app->params['SHOPIFY_SCOPE'];
      $redirect_uri = $base_url . '/site/install';
      header("Location: " . $shopifyClient->getAuthorizeUrl($shopify_scope, $redirect_uri));
      exit;
    } 
    else 
    {
        $sc = new Shopify($shopify_shop, $shopify_token, $app_key, $app_secret);
        $appSetup = new AppSetup();
        $appSetup->shop = $shopify_shop;
        $appSetup->token = $shopify_token;
        $appSetup->code = $code;
        $appSetup->status = 1;
        $appSetup->installation_process = 1;
        if($appSetup->save(false)){
           self::ShopifyHooks($sc,$shopify_shop);
        }
    }
  }
  $session = Yii::$app->session;
  $session->open();
  $session->set('shop', $shopify_shop);
  // echo '<pre>';
  // print_r($app_installed->installation_process); exit;
  if (!empty($app_installed)){ 
    if($app_installed['installation_process'] > 3){
    return $this->redirect('productlist');
    }
    else{
    $app_installed = AppSetup::find()->Where(['shop' => $shopify_shop])->one();
    $shopify_shop = $app_installed->shop;
    $shopify_token = $app_installed->token; 
    $sc = new Shopify($shopify_shop, $shopify_token, $app_key, $app_secret);
    self::ShopifyHooks($sc,$shopify_shop);
    return $this->redirect('importer');
    }
  } 
  else
  {
    echo "Something went wrong, please try again later.";
    exit;
  }
}

public Function actionImporter(){
  try{
    $app_setup = new AppSetup();
    $session = Yii::$app->session;
    $session->open();
    if(!empty($session)){
          $shop_name = $session->get('shop');
          $app_install = AppSetup::find()->Where(['shop' => $session->get('shop')])->one();
          $shop = $app_install['shop'];
          $token = $app_install['token'];
          $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);
          if($app_install['installation_process']==1){
              $shopifyProduct=$dbProducts = 0;
              /*check for total Product count in shopify*/
              $shopifyProduct = $sc->call('GET', '/admin/api/2019-04/products/count.json');

              /*Check for the total Product count in database for store*/
              $all_record = Product::find()->select(['product_id'])->orderBy(['product_id' => SORT_DESC])->all();
              $dbProducts = count($all_record);

              if($dbProducts==$shopifyProduct){
              /*Update InstalationProcess and redirect to Importer*/
               Yii::$app->db->createCommand()->update('store', ['installation_process' => 3])->execute(); 
               return $this->render('importer',array('dbProducts' => $dbProducts,'shopifyProduct'=>$shopifyProduct));
              }
              else 
              {
               /*load product Importing loader*/
               return $this->render('importer',array('dbProducts' => $dbProducts,'shopifyProduct'=>$shopifyProduct));
              }
          }
          else if($app_install['installation_process']==3)
          {
              //get all the products and its their varient from db
              $allproducts = Product::find()->Where(['store_name' => $session->get('shop')])->count(); 
              //$where['stock_queens_status']= ;
              $get_queens_products = Variant::find()->select('product_id')->Where(['store_name' => $session->get('shop')])->andWhere(['>', 'stock_queens_status', 0])->distinct()->count();
              $get_rons_products = Variant::find()->select('product_id')->Where(['store_name' => $session->get('shop')])->andWhere(['>','stock_rons_status', 0])->distinct()->count();
              $get_wilson_products = Variant::find()->select('product_id')->Where(['store_name' => $session->get('shop')])->andWhere(['>', 'stock_wils_status', 0])->distinct()->count();
              //echo print_r($get_updated_products); exit;
              $queen_variant_details = Variant::find()->Where(['stock_queens_status' => 0])->limit(10)->orderBy(['product_id' => SORT_ASC])->all();
              $rons_variant_details = Variant::find()->Where(['stock_rons_status' => 0])->limit(10)->orderBy(['product_id' => SORT_ASC])->all(); 
              $wilson_variant_details = Variant::find()->Where(['stock_wils_status' => 0])->limit(10)->orderBy(['product_id' => SORT_ASC])->all();
              $inventory_item_ids = array('queens'=>array(),'rons'=>array(),'wils'=>array());
              foreach($queen_variant_details as $key=>$value){
               $inventory_item_ids['queens'][]=$value->inventory_item_id;
              }
              foreach($rons_variant_details as $key=>$value){
               $inventory_item_ids['rons'][]=$value->inventory_item_id;
              }
              foreach($wilson_variant_details as $key=>$value){
              $inventory_item_ids['wils'][]=$value->inventory_item_id;
              } 
              if((count($inventory_item_ids['queens'])+count($inventory_item_ids['rons'])+ count($inventory_item_ids['wils']))>50){

              //echo (count($inventory_item_ids['queens'])+count($inventory_item_ids['rons'])+ count($inventory_item_ids['wils'])); exit;
              return $this->render('stockupdate',array('inventory_item_ids' => $inventory_item_ids,'product_count'=>$allproducts,'get_queens_products'=>$get_queens_products,'get_rons_products'=>$get_rons_products,'get_wilson_products'=>$get_wilson_products));
              }
              else {
              Yii::$app->db->createCommand()->update('store', ['installation_process' => 4])->execute(); 
              return $this->redirect('productlist');
              }
          }
          else {
            return $this->redirect('productlist');
          }
     }
    else {
      $shopify_scope = Yii::$app->params['SHOPIFY_SCOPE'];
      $redirect_uri = $base_url . '/site/install';
      header("Location: " . $shopifyClient->getAuthorizeUrl($shopify_scope, $redirect_uri));
      exit;
    }
  }
  catch(Exception $ex){
    throw new Exception("Error Processing Request", 1);   
  }
}

public function actionGetstock(){
    $request = Yii::$app->request;
    $shop_name = $request->post('shop');
    $q_invertorylist=$request->post('q_inventory_item_ids');
    $w_invertorylist=$request->post('w_inventory_item_ids');
    $r_invertorylist=$request->post('r_inventory_item_ids');
   

    $app_install = AppSetup::find()->Where(['id' => 1])->one();
    $shop = $app_install['shop'];
    $token = $app_install['token'];
    $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);

    $response=array('status'=>"false", "msg"=>"", 'qdata'=>array(),'wdata'=>array(),'rdata'=>array()); 
    $q_invertorylist.=','.$w_invertorylist.','.$r_invertorylist;   
    $q_inventory_details = $sc->call('GET', '/admin/api/2019-04/inventory_levels.json?inventory_item_ids='.$q_invertorylist);
    $txt="";
    foreach ($q_inventory_details as $loc){
      $variant_exist = Variant::find()->Where(['inventory_item_id' => $loc['inventory_item_id']])->one(); 
      if($loc['location_id'] == '49848851' ){        
        $variant_exist->stock_queens_status = 1;
        if($loc['available'] != ''){		   
            $variant_exist->queeninventory = $loc['available'];
           if($variant_exist->save(false)){
            $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Queensway stock updated to ".$loc['available'];
           }           
        }else{
          $variant_exist->save(false);
          $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Queensway location stock not avialable";  
          $txt .= "<br/>".$loc['inventory_item_id']."==>Queensway location stock not avialable";       
        }        
     }
     if($loc['location_id'] == '14372274199'){
      $variant_exist->stock_rons_status = 1;
       if($loc['available'] != ''){        
            $variant_exist->roninventory = $loc['available'];        
           if($variant_exist->save(false)){
            $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Ronsway stock updated to ".$loc['available'];
           }
         } 
         else 
         {
          $variant_exist->save(false);
          $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Ronsway location stock not avialable"; 
          $txt .= "<br/>".$loc['inventory_item_id']."==>Ronsway location stock not avialable";       
         }
     }
    if($loc['location_id'] == '14372306967')
    {   
        $variant_exist->stock_wils_status = 1;
        if($loc['available'] != ''){       
          $variant_exist->wilsoninventory = $loc['available']; 
          if($variant_exist->save(false)){
           $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Wilson stock updated to ".$loc['available'];
          }
        } else {
          $variant_exist->save(false);
          $response['msg'].= "<br/>".$loc['inventory_item_id']."==>Wilson location stock not avialable";          
          $txt .= "<br/>".$loc['inventory_item_id']."==>Wilson location stock not avialable";
        }
    }
     
    }
     // $myfile = fopen("Loc.html", "a") or die("Unable to open file!");
     //  fwrite($myfile, $txt);
     //  fclose($myfile);
    $response['qdata']=$q_inventory_details;
	  $response['status'] = true;
    return json_encode($response);
  }

 
public function actionProductlistapi(){
  $app_setup = new AppSetup();
  $session = Yii::$app->session;
  $session->open();
  // echo '<pre>';
  // print_r($session->get('shop')); exit;
 if(!empty($session)){
  $shop_name = $session->get('shop');
  $store_name = $session->get('id');
  //$app_install = AppSetup::find()->Where(['id' => 1])->one();
  $app_install = AppSetup::find()->Where(['shop' => $session->get('shop')])->one();
  $shop = $app_install['shop'];
  $token = $app_install['token'];
  $sc = new Shopify($shop,$token, Yii::$app->params['APP_KEY'], Yii::$app->params['SECRET_KEY']);
  $last_record = Product::find()->select(['product_id'])->orderBy(['product_id' => SORT_DESC])->one();
  $count_product = $sc->call('GET', '/admin/api/2019-04/products/count.json');
  //echo "<br/> Records in DB:".count(Product::find()->all());


  if (file_exists(dirname(__FILE__) . '/' . 'pageno.txt'))
  {    
        $fileContents = file_get_contents(dirname(__FILE__) . '/' . 'pageno.txt',FALSE, NULL); 
        $newContent = $fileContents + 1;
        file_put_contents(dirname(__FILE__) . '/' . 'pageno.txt', $newContent);
      if($fileContents >= 9){
        $fileContents = 2;
        file_put_contents(dirname(__FILE__) . '/' . 'pageno.txt', $fileContents);
      }
  } 
  else
  {   
      $fileContents = 2;
      file_put_contents(dirname(__FILE__) . '/' . 'pageno.txt', $fileContents);
  }
  if(!empty($last_record))
  {
    // echo "<br/> last_record:".$last_id = $last_record->product_id;
    $products_details = $sc->call('GET', '/admin/api/2019-04/products.json?limit=100&page='.$fileContents); 
  } 
  else
  {
     $fileContent = 1;
     $products_details = $sc->call('GET', '/admin/api/2019-04/products.json?limit=100');
  }

 // echo "Records fetched:".count($products_details);
  $fileContents++;
  if(!empty($products_details)){
    foreach ($products_details as $value) 
    { 
     // echo "<br/>'".$value['id']."'";
      
      $product_exist = Product::find()->Where(['product_id' => $value['id']])->one();
      if(empty($product_exist))
      {
          //echo "==> new ";
          $product = new Product();
          $product->product_id = $value['id'];
          $product->title = $value['title'];
          $product->image_src = $value['image']['src'];
          $product->vendor = $value['vendor'];
          $product->product_type = $value['product_type'];
          $product->store_name = $session->get('shop');

          if ($product->save(false)) {
          foreach ($value['variants'] as $var) {
            $variant = new Variant();
            $variant->product_id = $value['id'];
            $variant->title = $var['title'];
            $variant->price = $var['price'];
            $variant->inventory_item_id = $var['inventory_item_id'];
            $variant->inventory_quantity = $var['inventory_quantity'];
            $variant->old_inventory_quantity = $var['old_inventory_quantity'];
            $variant->variants_id = $var['id'];
             $variant->queenLevel = 100;
            $variant->ronLevel = 100;
            $variant->wilsonLevel = 100;
            $variant->queeninventory = 0;
            $variant->roninventory = 0;
            $variant->wilsoninventory =0;
            $variant->store_name = $session->get('shop');
            $variant->save(false);
           }
         }
      }  
    else 
      {
        // already is not exist end;
        // already is exist then update the record end;
        // echo "==> already";
        $product_exist->product_id = $value['id'];
        $product_exist->title = $value['title'];
        $product_exist->image_src = $value['image']['src'];
        $product_exist->vendor = $value['vendor'];
        $product_exist->product_type = $value['product_type'];
        $product->store_name = $session->get('shop');
        if ($product_exist->save(false)) {

          foreach ($value['variants'] as $var) {
            $variant_exist = Variant::find()->Where(['variants_id' => $var['id']])->one();
            $variant_exist->product_id = $value['id'];
            $variant_exist->title = $var['title'];
            $variant_exist->price = $var['price'];
            $variant_exist->inventory_item_id = $var['inventory_item_id'];
            $variant_exist->inventory_quantity = $var['inventory_quantity'];
            $variant_exist->old_inventory_quantity = $var['old_inventory_quantity'];
            $variant_exist->variants_id = $var['id'];
            $variant_exist->queenLevel = 100;
            $variant_exist->ronLevel = 100;
            $variant_exist->wilsonLevel = 100;
            $variant_exist->queeninventory = 0;
            $variant_exist->roninventory = 0;
            $variant_exist->wilsoninventory =0;
            $variant->store_name = $session->get('shop');
            $variant_exist->save(false);
          }
    
        }

      } 
      // already is exist then update the record end;
    }
  } 
  //else {
  //$fileContent = 0;
  //echo 'All product imported';
  // }  
  $all_record = Product::find()->all();
  $dbProducts = count($all_record);
  $result = array("validation" => "true","dbProducts"=>$dbProducts);
  $res = json_encode($result);
  echo "myJsonMethod(".$res.")";
  exit;

//  return $dbProducts;
}
else
{
  $shopify_scope = Yii::$app->params['SHOPIFY_SCOPE'];
  $redirect_uri = $base_url . '/site/install';
  header("Location: " . $shopifyClient->getAuthorizeUrl($shopify_scope, $redirect_uri));
  exit;
 }

}


/**
*  app uninstall hook to delete app entry from table
*/
public function actionAppuninstalled(){
  $shop = Yii::$app->request->get('shop');
  $AppSetup = AppSetup::find()->where(['shop' => $shop])->one();
  $AppSetup->delete();
}

protected function findModel($id) {
  if (($model =  product::findOne($id)) !== null) {
    return $model;
  }
 throw new NotFoundHttpException('The requested page does not exist.');
}

}
