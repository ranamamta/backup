<?php
return [
	'adminEmail' => 'admin@example.com',
	'APP_KEY'    => 'eff12ca0c34fa2e9ccc898ee71a9d90b',
	'SECRET_KEY' => 'a993c8c68ce264237899fde891e68d31',
	'SHOPIFY_SCOPE' =>'read_content,write_content,read_customers,write_customers,read_themes,write_themes,read_products,write_products,read_inventory,write_inventory',
	'REDIRECT_URI' => 'http://kurinato.com/levelapp/web/index.php',
	'BASE_URL' => 'https://kurinato.com/levelapp/web/index.php',
	'senderEmail' => 'noreply@example.com',
	'senderName' => 'Example.com mailer',
];
