<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=levelapp_DB',
    'username' => 'levelapp_USR',
    'password' => 'Ld1PcQF39Q3J',
    'charset' => 'utf8'

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
