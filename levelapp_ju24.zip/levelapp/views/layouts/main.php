<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <script type="text/javascript">
        var IdealTimeOut = 600; //10 seconds
        var idleSecondsTimer = null;
        var idleSecondsCounter = 0;
        document.onclick = function () {idleSecondsCounter = 0;};
        document.onmousemove = function () {idleSecondsCounter = 0;};
        document.onkeypress = function () {idleSecondsCounter = 0;};
        idleSecondsTimer = window.setInterval(CheckIdleTime, 1000);
 
        function CheckIdleTime() {
            idleSecondsCounter++;
            var oPanel = document.getElementById("timeOut");
            if (oPanel) {
                oPanel.innerHTML = (IdealTimeOut - idleSecondsCounter);
            }
            if (idleSecondsCounter >= IdealTimeOut) {
                window.clearInterval(idleSecondsTimer);
                alert("You have no activity on this page from last 10 minute,So you are getting disconnected from the Server.Please click on OK to reconnect.");
                 $("#load").show();
                window.location = "http://kurinato.com/levelapp/web/index.php/site/productlist";
            }
        }
    </script>
</head>
<body>
<?php $this->beginBody() ?>
<!--  <form id="form1" runat="server">
    <div>
        You will be auto logged out in <span id="timeOut"></span> seconds.
    </div>
    </form> -->
<div class="wrap">
    <?php
	/*
    NavBar::begin([
        'brandLabel' => Yii::$app->name,
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Home', 'url' => ['/site/index']],
            ['label' => 'About', 'url' => ['/site/about']],
            ['label' => 'Contact', 'url' => ['/site/contact']],
            Yii::$app->user->isGuest ? (
                ['label' => 'Login', 'url' => ['/site/login']]
            ) : (
                '<li>'
                . Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Logout (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'btn btn-link logout']
                )
                . Html::endForm()
                . '</li>'
            )
        ],
    ]);
    NavBar::end();*/
    ?>
 <div id="load"></div> 
 <div class="container">
    <?= Breadcrumbs::widget([
    'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
    ]) ?>
    <?= Alert::widget() ?>
    <?= $content ?>
 </div>
</div>

<footer class="footer">
<div class="container">
<p class="pull-left">&copy; My Company <?= date('Y') ?></p>
<p class="pull-right"><?= Yii::powered() ?></p>
</div>
</footer>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery('#load').hide();
});
 
// (function(seconds) {
// var refresh,       
//     intvrefresh = function() {
//         clearInterval(refresh);
//         refresh = setTimeout(function() {
//            location.href = location.href;
//         }, seconds * 1000);
//     };

// $(document).on('keypress hover', function() { intvrefresh() });
// intvrefresh();
// }(15));

</script>
<?php $this->endBody() ?>

</body>
</html>
<?php $this->endPage() ?>
