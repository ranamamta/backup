<?php
use yii\helpers\Url;
use yii\helpers\Html;
use app\models\AppSetup;
use yii\bootstrap\ActiveForm;
?>
<div class="row col-lg-12">

<h1 class="importer_count">Importing <?php echo $dbProducts .'/'. $shopifyProduct?> Products</h1>
<div id="loader" class="text-center" style="display:block;"></div>
</div>
<!-- <input type="hidden" id="count" value="<?php //echo $shopifyProduct; ?>">
 -->

<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
jQuery(document).ready(function(){
Importproducts();
});
var counter=0;
var url='https://kurinato.com/levelapp/web/index.php/site/';
Importproducts();
function Importproducts(){

    jQuery.ajax({
        type: 'POST',
        url: 'https://kurinato.com/levelapp/web/index.php/site/productlistapi',
       // dataType: 'html',
        // beforeSend: function(){
        // $("#load").show();
        // },
        dataType: 'jsonp',
        headers: {"Access-Control-Allow-Origin": "*"},
        crossOrigin: true,
        async: false,
        jsonp: false,
        jsonpCallback: "myJsonMethod",
        complete: function(){
          if(counter >= 9){
               window.location=url+'importer'; 
            }
        },
        success: function(response){
          console.log(response.dbProducts);
        var shopifyProduct = '<?php echo $shopifyProduct; ?>';
        var imported_product = response.dbProducts;
        //alert(imported_product);
        jQuery(".importer_count").html("<h1 class='importer_count'>Importing "+imported_product+'/'+shopifyProduct+" Products</h1>");
        console.log(response);
        counter++;
        if(counter <= 9){
         Importproducts();
        }
        else{
         $("#load").hide();
         jQuery(".importer_count").html("<h1 class='importer_count'>Imported "+imported_product+'/'+shopifyProduct+" Products</h1>");
        }
      
        }
  });
}



</script>

<style type="text/css">
  #loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>