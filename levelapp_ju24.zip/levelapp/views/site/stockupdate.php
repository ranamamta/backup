<?php
use yii\helpers\Url;
use yii\helpers\Html;
use app\models\AppSetup;
use yii\bootstrap\ActiveForm;
?>

<?php $counter=0;

//echo "<pre>";print_r($inventory_item_ids);exit;?>
<input type="hidden" id="queen"  value='<?php echo implode(",",$inventory_item_ids["queens"])?>'/>
<input type="hidden" id="rons"  value='<?php echo implode(",",$inventory_item_ids["rons"])?>'/>
<input type="hidden" id="wils"  value='<?php echo implode(",",$inventory_item_ids["wils"])?>'/>


<div class="row col-lg-12">
    <h3 class="importer_count">Update Inventory Stock for Queensway products:<span id="pid"></span> </h3>
    <h4> Processing <span id="cid"><?php echo $get_queens_products?> </span>/ <?php echo $product_count?></h4>

    <h3 class="importer_count">Update Inventory Stock for Rons products:<span id="pid"></span> </h3>
    <h4> Processing <span id="cid"><?php echo $get_rons_products?> </span>/ <?php echo $product_count?></h4>


    <h3 class="importer_count">Update Inventory Stock for Wilson products:<span id="pid"></span> </h3>
    <h4> Processing <span id="cid"><?php echo $get_wilson_products?> </span>/ <?php echo $product_count?></h4>
    <div id="stock_loader" class="text-center" style="display:block;"></div>
    <div id="dispalyer"></div>
</div> 



<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
jQuery(document).ready(function(){
 UpdateStock();
});
var counter=0;
var url='https://kurinato.com/levelapp/web/index.php/site/';


//UpdateStock();

function UpdateStock(){
  console.log(counter);
  var q_inventory_item_ids= jQuery('#queen').val();
  var r_inventory_item_ids= jQuery('#rons').val();
  var w_inventory_item_ids= jQuery('#wils').val();
  // console.log(q_inventory_item_ids);
  // console.log(r_inventory_item_ids);
  
  // console.log(w_inventory_item_ids);
  
  jQuery.post(url+'getstock',{q_inventory_item_ids:q_inventory_item_ids,r_inventory_item_ids:r_inventory_item_ids,w_inventory_item_ids:w_inventory_item_ids},function(j){
    console.log(j.msg);
    jQuery('#stock_loader').hide();
    jQuery('#dispalyer').append(j.msg); 
    console.log(j.msg); 
    setTimeout(function(){ window.location.reload(); }, 10000);
    },'json');
}
</script>

<style type="text/css">
  #stock_loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>