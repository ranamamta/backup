  jQuery(document).ready(function() {

  jQuery('#example').DataTable();

  } );

  $(document).ready(function(){
    $('a[href^="#"]').on('click',function (e) {
        e.preventDefault();

        var target = this.hash;
        var $target = $(target);

        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });
});


  // edit functionality
$(document).on("click", ".open-AddBookDialog",function(event){
event.preventDefault();
var myBookId = $(this).attr('data-id');
var queenlavel = $(this).attr('data-queen');
var ronlevel = $(this).attr('data-rons');
var wils = $(this).attr('data-wilson');
$(".modal-body input#variant-variants_id").val(myBookId);
$(".modal-body input#variant-queenlevel").val(queenlavel);
$(".modal-body input#variant-ronlevel").val(ronlevel);
$(".modal-body input#variant-wilsonlevel").val(wils);
});



/*jquery to load data as per loaction*/
jQuery(document).ready(function(){
    $('#location').on('change', function () {
        showHideLocation(this.value); 
    });
  
  showHideLocation('<?php echo $sel_location?>');
});

function showHideLocation(loc){
  if (loc == 'Queensway') 
        {
          $(".queen").addClass('activeshow');
          $(".queen").removeClass('activehide');
      
          $(".ron").addClass('activehide');
          $(".ron").removeClass('activeshow');
      
          $(".wilson").addClass('activehide');
          $(".wilson").removeClass('activeshow');

          if($('input#order_tobe').prop("checked") == true)
          {
            var table = $("table tbody");
            table.find('tr.active_row').each(function (i) 
            {   $(this).removeClass("current");
                var tds = $(this).find('td.show_record_child');
                var queen = tds.eq(0).text();
                if((queen <= 0))
                {
                  var myclass= tds.eq(0).attr("class");
                  if ( myclass =="queen show_record_child activeshow" )
                   {
                      $(this).addClass("current");
                   }
                }
            });
          }
        }
        else if(loc == 'Roncesvalles') 
        {
            $(".ron").addClass('activeshow');
            $(".ron").removeClass('activehide');
            $(".queen").addClass('activehide');
            $(".queen").removeClass('activeshow');
            $(".wilson").addClass('activehide');
            $(".wilson").removeClass('activeshow');
        if($('input#order_tobe').prop("checked") == true)
        {
        var table = $("table tbody");
        table.find('tr.active_row').each(function (i) 
        {  
          $(this).removeClass("current");
          var tds = $(this).find('td.show_record_child');
          var ron = tds.eq(1).text();
          if((ron <= 0))
          {
          var myclass= tds.eq(1).attr("class");
          if (myclass =="ron show_record_child activeshow" ) 
          {
            $(this).addClass("current");
          }
          }
        });
        }
        }
        else if(loc == 'Wilson')
        {
            $(".wilson").addClass('activeshow');
            $(".wilson").removeClass('activehide');
            $(".queen").addClass('activehide');
            $(".queen").removeClass('activeshow');
            $(".ron").addClass('activehide');
            $(".ron").removeClass('activeshow');
      
          if($('input#order_tobe').prop("checked") == true)
          {
            var table = $("table tbody");
            table.find('tr.active_row').each(function (i) 
            {
              $(this).removeClass("current");
              var tds = $(this).find('td.show_record_child');
              var wilson = tds.eq(2).text();
              if((wilson <= 0))
              {
                var myclass= tds.eq(2).attr("class");
                if ( myclass =="wilson show_record_child activeshow" ) 
                {
                   $(this).addClass("current");
                }
              }
            });
          }
        }
        else {
          $(".queen").removeClass('activehide');
          $(".ron").addClass('activehide');
          $(".wilson").addClass('activehide');
        }
}

// jQuery on click of checkkbox and check the value of location

 $('input#order_tobe').click(function(){
    if($(this).prop("checked") == true){
   var selected = $("#location").children("option:selected").val();
   if(selected == 'Roncesvalles'){
   // console.log(selected);
     var table = $("table tbody");
     table.find('tr.active_row').each(function (i) {
     $(this).removeClass("current");
     var tds = $(this).find('td.show_record_child');
     var ron =  tds.eq(1).text();
     if((ron <= 0)){
      $(this).addClass("current");
    }
   });
  }
  else if(selected == 'Wilson'){
     var table = $("table tbody");
     table.find('tr.active_row').each(function (i) {
     $(this).removeClass("current");
     var tds = $(this).find('td.show_record_child');
     var wilson =  tds.eq(2).text();
     if((wilson <= 0)){
      $(this).addClass("current");
    }
   });
  } else {
    var table = $("table tbody");
    table.find('tr.active_row').each(function (i) {
    $(this).removeClass("current");
    var tds = $(this).find('td.show_record_child');
    var queen = tds.eq(0).text();
    if((queen <= 0)){
    $(this).addClass("current");
    }
    });
 }

 }
 else
 {
  $("#load").show();
  location.reload();
}
});

var url='http://kurinato.com/levelapp/web/index.php/site/';
jQuery(document).ready(function(){
jQuery('select.levelfilters').on('change', function(){
 $("#order_tobe").prop("checked", false);
      var product_type = jQuery('select#product').children("option:selected").val();
      var vender = jQuery('select#vender').children("option:selected").val();
      var location = jQuery('select#location').children("option:selected").val();
      var query = jQuery('#query').val();
      console.log(product_type); 
      console.log(vender);
      $("#load").show();
      window.location=url+'productlist?page=1&product_type='+product_type+'&vendor='+vender+'&query='+query+'&location='+location;
});

jQuery('.example_filll').on('keyup',function () { 
   $("#order_tobe").prop("checked", false);
   var search_content = jQuery(this).val();
   console.log(search_content);
   if(search_content.length>3){
    $("#load").show();
    $("#order_tobe").prop("checked", false);
     var product_type = jQuery('select#product').children("option:selected").val();
     var vender = jQuery('select#vender').children("option:selected").val();
     var query = jQuery('#query').val();
     var location = jQuery('select#location').children("option:selected").val();
     console.log(product_type); 
     console.log(vender);
     $("#load").show();
     window.location=url+'productlist?page=1&product_type='+product_type+'&vendor='+vender+'&query='+query+'&location='+location;
   }
   
 });



});

function changepage(page){
  $("#order_tobe").prop("checked", false);
   var product_type = jQuery('select#product').children("option:selected").val();
   var vender = jQuery('select#vender').children("option:selected").val();
   var query = jQuery('#query').val();
   var location = jQuery('select#location').children("option:selected").val();
   console.log(product_type); 
   console.log(vender);
   $("#load").show();
   window.location=url+'productlist?page='+page+'&product_type='+product_type+'&vendor='+vender+'&query='+query+'&location='+location;
}

$("#editupdate").click(function(e) {
  var make_id = $(".modal-body input#variant-variants_id").val();
  var new_id = 'set_'+make_id;
  console.log(new_id);
});
