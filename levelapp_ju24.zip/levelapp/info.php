<?php
phpinfo();

?>